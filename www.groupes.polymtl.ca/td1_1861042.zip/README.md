Ce trvail a ete realise par Mohamed Amine Barrak, matricule : 1861042
Exemple pour executer le code: 
python3 tp1.py train.txt
